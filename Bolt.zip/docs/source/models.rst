models package
==============

Submodules
----------

models.spacy_model module
-------------------------

.. automodule:: models.spacy_model
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: models
    :members:
    :undoc-members:
    :show-inheritance:
