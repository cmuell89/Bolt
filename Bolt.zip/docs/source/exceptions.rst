exceptions module
=================

.. automodule:: exceptions
    :members:
    :undoc-members:
    :show-inheritance:
