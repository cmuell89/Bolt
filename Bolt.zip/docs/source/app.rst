app package
===========

Submodules
----------

app.resources module
--------------------

.. automodule:: app.resources
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: app
    :members:
    :undoc-members:
    :show-inheritance:
